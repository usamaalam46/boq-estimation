
import { useEffect, useState } from "react";
import api from "../../api/axios";
import "./Projects.css";

interface Project {
    id: string;
    name: string;
    code: string | null;
    description: string | null;
    createdAt: string;
    organization: {
        id: string;
        name: string;
        slug: string;
    };
    _count: {
        estimates: number;
    };
}

interface ProjectsResponse {
    success: boolean;
    data: Project[];
    pagination: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
}

export default function Projects() {
    const [projects, setProjects] = useState<Project[]>([]);
    const [search, setSearch] = useState("");
    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);
    const [totalPages, setTotalPages] = useState(0);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        let cancelled = false;

        async function loadProjects() {
            setLoading(true);
            setError("");

            try {
                const response = await api.get<ProjectsResponse>("/projects", {
                    params: {
                        page,
                        limit: 10,
                        ...(search.trim() ? { search: search.trim() } : {}),
                    },
                });

                if (cancelled) return;

                setProjects(response.data.data);
                setTotal(response.data.pagination.total);
                setTotalPages(response.data.pagination.totalPages);
            } catch (err: unknown) {
                if (cancelled) return;

                const message =
                    typeof err === "object" &&
                        err !== null &&
                        "response" in err
                        ? (
                            err as {
                                response?: {
                                    data?: { message?: string };
                                };
                            }
                        ).response?.data?.message
                        : undefined;

                setError(message || "Unable to load projects.");
            } finally {
                if (!cancelled) setLoading(false);
            }
        }

        void loadProjects();

        return () => {
            cancelled = true;
        };
    }, [page, search]);

    return (
        <div className="projects-page">
            <div className="projects-header">
                <div>
                    <h1>Projects</h1>
                    <p>Manage projects and their organization assignments.</p>
                </div>
            </div>

            <div className="projects-toolbar">
                <input
                    type="search"
                    placeholder="Search project, code, or organization..."
                    value={search}
                    onChange={(event) => {
                        setSearch(event.target.value);
                        setPage(1);
                    }}
                />
                <span>{total} projects</span>
            </div>

            {error && <div className="projects-error">{error}</div>}

            <div className="projects-table-wrapper">
                <table className="projects-table">
                    <thead>
                        <tr>
                            <th>Project</th>
                            <th>Code</th>
                            <th>Organization</th>
                            <th>Estimates</th>
                            <th>Created</th>
                        </tr>
                    </thead>

                    <tbody>
                        {loading ? (
                            <tr>
                                <td colSpan={5} className="projects-empty">
                                    Loading projects...
                                </td>
                            </tr>
                        ) : projects.length === 0 ? (
                            <tr>
                                <td colSpan={5} className="projects-empty">
                                    No projects found.
                                </td>
                            </tr>
                        ) : (
                            projects.map((project) => (
                                <tr key={project.id}>
                                    <td>
                                        <strong>{project.name}</strong>
                                        {project.description && (
                                            <p className="project-description">
                                                {project.description}
                                            </p>
                                        )}
                                    </td>
                                    <td>{project.code || "—"}</td>
                                    <td>
                                        <span className="project-organization">
                                            {project.organization.name}
                                        </span>
                                    </td>
                                    <td>{project._count.estimates}</td>
                                    <td>
                                        {new Date(project.createdAt).toLocaleDateString()}
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            <div className="projects-pagination">
                <span>
                    {total === 0
                        ? "Showing 0 projects"
                        : `Showing ${(page - 1) * 10 + 1}–${Math.min(
                            page * 10,
                            total,
                        )} of ${total}`}
                </span>

                <div>
                    <button
                        type="button"
                        disabled={loading || page <= 1}
                        onClick={() => setPage((current) => current - 1)}
                    >
                        Previous
                    </button>

                    <span>
                        Page {totalPages === 0 ? 0 : page} of {totalPages}
                    </span>

                    <button
                        type="button"
                        disabled={loading || page >= totalPages}
                        onClick={() => setPage((current) => current + 1)}
                    >
                        Next
                    </button>
                </div>
            </div>
        </div>
    );
}
