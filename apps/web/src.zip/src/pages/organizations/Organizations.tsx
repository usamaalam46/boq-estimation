
import { useCallback, useEffect, useState } from "react";
import { Search, Building2, Users, FolderKanban, ChevronLeft, ChevronRight, RefreshCw } from "lucide-react";
import api from "../../api/axios";
import "./Organizations.css";

interface Organization {
    id: string;
    name: string;
    slug: string;
    address: string | null;
    location: string | null;
    isActive: boolean;
    createdAt: string;
    _count: {
        members: number;
        projects: number;
    };
}

interface OrganizationResponse {
    success: boolean;
    data: Organization[];
    pagination: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
    message?: string;
}

const PAGE_SIZE = 10;

export default function Organizations() {
    const [organizations, setOrganizations] = useState<Organization[]>([]);
    const [searchInput, setSearchInput] = useState("");
    const [search, setSearch] = useState("");
    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);
    const [totalPages, setTotalPages] = useState(0);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    const loadOrganizations = useCallback(async () => {
        setLoading(true);
        setError("");

        try {
            const response = await api.get<OrganizationResponse>(
                "/organizations",
                {
                    params: {
                        page,
                        limit: PAGE_SIZE,
                        ...(search ? { search } : {}),
                    },
                }
            );

            setOrganizations(response.data.data);
            setTotal(response.data.pagination.total);
            setTotalPages(response.data.pagination.totalPages);
        } catch (err: unknown) {
            const message =
                typeof err === "object" &&
                    err !== null &&
                    "response" in err &&
                    typeof err.response === "object" &&
                    err.response !== null &&
                    "data" in err.response &&
                    typeof err.response.data === "object" &&
                    err.response.data !== null &&
                    "message" in err.response.data &&
                    typeof err.response.data.message === "string"
                    ? err.response.data.message
                    : "Unable to load organizations. Please try again.";

            setError(message);
        } finally {
            setLoading(false);
        }
    }, [page, search]);

    useEffect(() => {
        void loadOrganizations();
    }, [loadOrganizations]);

    function handleSearch(event: React.FormEvent<HTMLFormElement>) {
        event.preventDefault();
        setPage(1);
        setSearch(searchInput.trim());
    }

    const startRecord = total === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;
    const endRecord = Math.min(page * PAGE_SIZE, total);

    const pageNumbers = Array.from(
        { length: totalPages },
        (_, index) => index + 1
    ).filter(
        (pageNumber) =>
            pageNumber === 1 ||
            pageNumber === totalPages ||
            Math.abs(pageNumber - page) <= 1
    );

    return (
        <section className="organizations-page">
            <div className="organizations-heading">
                <div>
                    <h1>Organizations</h1>
                    <p>Manage organizations registered on the BOQ platform.</p>
                </div>

                <button
                    type="button"
                    className="organizations-refresh"
                    onClick={() => void loadOrganizations()}
                    disabled={loading}
                >
                    <RefreshCw size={16} />
                    Refresh
                </button>
            </div>

            <div className="organizations-summary">
                <div className="organization-summary-card">
                    <div className="organization-summary-icon">
                        <Building2 size={20} />
                    </div>
                    <div>
                        <span>Total organizations</span>
                        <strong>{total}</strong>
                    </div>
                </div>

                <div className="organization-summary-card">
                    <div className="organization-summary-icon">
                        <Users size={20} />
                    </div>
                    <div>
                        <span>Organizations on this page</span>
                        <strong>{organizations.length}</strong>
                    </div>
                </div>

                <div className="organization-summary-card">
                    <div className="organization-summary-icon">
                        <FolderKanban size={20} />
                    </div>
                    <div>
                        <span>Current page</span>
                        <strong>{totalPages ? `${page} / ${totalPages}` : "0 / 0"}</strong>
                    </div>
                </div>
            </div>

            <div className="organizations-panel">
                <div className="organizations-toolbar">
                    <div>
                        <h2>All organizations</h2>
                        <p>View organization details, members and projects.</p>
                    </div>

                    <form className="organizations-search" onSubmit={handleSearch}>
                        <Search size={18} />
                        <input
                            type="search"
                            value={searchInput}
                            onChange={(event) => setSearchInput(event.target.value)}
                            placeholder="Search name or slug..."
                            aria-label="Search organizations by name or slug"
                        />
                        <button type="submit">Search</button>
                    </form>
                </div>

                {error && (
                    <div className="organizations-error" role="alert">
                        <span>{error}</span>
                        <button type="button" onClick={() => void loadOrganizations()}>
                            Try again
                        </button>
                    </div>
                )}

                <div className="organizations-table-wrapper">
                    <table className="organizations-table">
                        <thead>
                            <tr>
                                <th>Organization</th>
                                <th>Location</th>
                                <th>Members</th>
                                <th>Projects</th>
                                <th>Status</th>
                                <th>Created</th>
                            </tr>
                        </thead>

                        <tbody>
                            {loading ? (
                                <tr>
                                    <td colSpan={6} className="organizations-message">
                                        Loading organizations...
                                    </td>
                                </tr>
                            ) : error ? (
                                <tr>
                                    <td colSpan={6} className="organizations-message">
                                        Organization data could not be loaded.
                                    </td>
                                </tr>
                            ) : organizations.length === 0 ? (
                                <tr>
                                    <td colSpan={6} className="organizations-message">
                                        {search
                                            ? "No organizations match your search."
                                            : "No organizations have been created yet."}
                                    </td>
                                </tr>
                            ) : (
                                organizations.map((organization) => (
                                    <tr key={organization.id}>
                                        <td>
                                            <div className="organization-name-cell">
                                                <div className="organization-avatar">
                                                    {organization.name.charAt(0).toUpperCase()}
                                                </div>
                                                <div>
                                                    <strong>{organization.name}</strong>
                                                    <span>{organization.slug}</span>
                                                </div>
                                            </div>
                                        </td>

                                        <td>
                                            {organization.location ||
                                                organization.address ||
                                                "—"}
                                        </td>

                                        <td>{organization._count.members}</td>
                                        <td>{organization._count.projects}</td>

                                        <td>
                                            <span
                                                className={`organization-status ${organization.isActive ? "is-active" : "is-inactive"
                                                    }`}
                                            >
                                                {organization.isActive ? "Active" : "Inactive"}
                                            </span>
                                        </td>

                                        <td>
                                            {new Date(organization.createdAt).toLocaleDateString()}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>

                <div className="organizations-pagination">
                    <span>
                        Showing {startRecord}–{endRecord} of {total} organizations
                    </span>

                    <div className="organizations-pagination-controls">
                        <button
                            type="button"
                            aria-label="Previous page"
                            disabled={loading || page <= 1}
                            onClick={() => setPage((current) => current - 1)}
                        >
                            <ChevronLeft size={17} />
                        </button>

                        {pageNumbers.map((pageNumber, index) => (
                            <span className="organization-page-number" key={pageNumber}>
                                {index > 0 &&
                                    pageNumber - pageNumbers[index - 1] > 1 && <span>…</span>}
                                <button
                                    type="button"
                                    className={pageNumber === page ? "current" : ""}
                                    aria-current={pageNumber === page ? "page" : undefined}
                                    disabled={loading}
                                    onClick={() => setPage(pageNumber)}
                                >
                                    {pageNumber}
                                </button>
                            </span>
                        ))}

                        <button
                            type="button"
                            aria-label="Next page"
                            disabled={loading || page >= totalPages}
                            onClick={() => setPage((current) => current + 1)}
                        >
                            <ChevronRight size={17} />
                        </button>
                    </div>
                </div>
            </div>
        </section>
    );
}
